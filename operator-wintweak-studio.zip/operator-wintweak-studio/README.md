# Operator WinTweak Studio

An operator-grade **defensive** Windows hardening, privacy, performance, and audit script generator.

This project is designed to look and feel elite while staying transparent, legal, and GitHub-safe. It generates readable PowerShell scripts for you to review and run yourself.

## What it does

- Defensive Windows hardening profiles
- Privacy tuning profiles
- Gaming/performance profiles
- Developer/Explorer quality-of-life profiles
- Read-only audit/recon reports for your own PC
- APPLY script generation
- UNDO script generation where possible
- AUDIT script generation
- Full script bundle export
- Restore-point-first workflow
- Registry snapshot exports

## What it intentionally does NOT do

- No exploit chains
- No malware persistence
- No credential theft
- No stealth behavior
- No Microsoft Defender bypass
- No Windows Firewall disable
- No Windows Update disable
- No SmartScreen disable
- No UAC disable

## Included tweak areas

### Safety

- Create system restore point
- Export registry safety snapshots

### Hardening

- Ensure Windows Firewall is enabled
- Ensure Microsoft Defender protections are enabled
- Enable PUA protection
- Enable SmartScreen / app reputation checks
- Ensure UAC is enabled
- Disable AutoRun / AutoPlay execution
- Disable SMBv1
- Disable LLMNR
- Reduce WPAD auto-proxy exposure
- Require NLA for RDP
- Optional inbound RDP disable

### Privacy

- Disable advertising ID
- Disable tailored experiences
- Disable activity history publishing/upload
- Disable app launch tracking
- Reduce feedback prompts
- Reduce Windows suggestions/tips
- Disable web suggestions in Windows Search

### Performance / Gaming

- Clean user temp files
- Flush DNS cache
- DISM component cleanup
- SFC system file scan
- High Performance power plan
- Visual effects performance mode
- Reduce animations
- Disable transparency effects
- Enable Game Mode
- Disable Game DVR background capture
- Optional Hardware Accelerated GPU Scheduling

### Audit / Defensive Recon

- Startup commands
- Listening TCP ports
- Defender status
- Firewall profiles and enabled rules
- Auto-start services
- Local users and admins
- Installed updates
- Installed apps
- Network configuration

## Install and run

Install Node.js LTS first:

<https://nodejs.org/>

Then:

```powershell
npm install
npm start
```

## Build Windows `.exe`

```powershell
npm run make:win
```

Output appears in:

```text
release
```

## GitHub push

```bash
git init
git add .
git commit -m "Initial release"
git branch -M main
git remote add origin https://github.com/YOURNAME/operator-wintweak-studio.git
git push -u origin main
```

## Recommended workflow

1. Open the app.
2. Pick a profile.
3. Review the Tweak Matrix.
4. Save the full bundle.
5. Run the AUDIT script first.
6. Read the APPLY script.
7. Run APPLY from Administrator PowerShell only if you agree with the changes.
8. Keep the UNDO script and registry backups.

## Disclaimer

Use at your own risk. Windows versions and policies vary. Always read generated scripts before running them.
