# Profiles

Profiles are sets of tweak IDs loaded by the app.

Built-in profiles:

- Baseline Safe
- Defensive Hardening
- Privacy Respect
- Performance / Low-End
- Gaming Rig
- Developer Mode
- Recon / Audit Only

Future idea: export/import profiles as JSON.
