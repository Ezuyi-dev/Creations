# Security Policy

## Project stance

Operator WinTweak Studio is a defensive tuning and audit tool. It is not an exploitation framework.

Allowed contributions:

- Defensive hardening
- Privacy-respecting settings
- Performance tuning
- Read-only audits
- Clear undo commands
- Documentation improvements

Not allowed:

- Exploit automation
- Credential theft or dumping
- Persistence mechanisms
- Stealth/evasion behavior
- Microsoft Defender bypass/disable logic
- Firewall disable logic
- Windows Update disable logic
- SmartScreen disable logic
- UAC disable logic
- Obfuscated PowerShell
- Download-and-execute payloads

## Script safety standards

Every tweak should be:

1. Human-readable
2. Documented
3. Opt-in
4. Reversible where possible
5. Honest about admin/reboot/risk requirements

## Reporting security issues

If you discover a security issue, please report it privately to the maintainer before public disclosure.
