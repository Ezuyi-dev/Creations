const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const os = require('os');
const fs = require('fs/promises');
const { execFile } = require('child_process');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1320,
    height: 860,
    minWidth: 980,
    minHeight: 650,
    frame: false,
    title: 'Operator WinTweak Studio',
    icon: path.join(__dirname, '..', 'assets', 'icon.png'),
    backgroundColor: '#050914',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

ipcMain.handle('window:minimize', () => mainWindow?.minimize());
ipcMain.handle('window:maximize', () => {
  if (!mainWindow) return false;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
  return mainWindow.isMaximized();
});
ipcMain.handle('window:close', () => mainWindow?.close());

ipcMain.handle('system:info', () => {
  const cpus = os.cpus() || [];
  return {
    platform: os.platform(),
    release: os.release(),
    arch: os.arch(),
    hostname: os.hostname(),
    username: os.userInfo().username,
    cpu: cpus[0]?.model || 'Unknown CPU',
    cores: cpus.length,
    totalMemoryGB: Number((os.totalmem() / 1024 / 1024 / 1024).toFixed(2)),
    freeMemoryGB: Number((os.freemem() / 1024 / 1024 / 1024).toFixed(2)),
    uptimeHours: Number((os.uptime() / 3600).toFixed(1)),
    home: os.homedir(),
    downloads: app.getPath('downloads'),
    documents: app.getPath('documents')
  };
});

ipcMain.handle('script:save', async (_event, payload) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: payload?.title || 'Save PowerShell script',
    defaultPath: path.join(app.getPath('documents'), payload?.defaultName || 'operator-wintweak.ps1'),
    filters: [{ name: 'PowerShell Script', extensions: ['ps1'] }, { name: 'Text', extensions: ['txt'] }]
  });
  if (result.canceled || !result.filePath) return { canceled: true };
  await fs.writeFile(result.filePath, payload?.text || '', 'utf8');
  return { canceled: false, filePath: result.filePath };
});

ipcMain.handle('script:save-bundle', async (_event, bundle) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Choose folder for script bundle',
    defaultPath: app.getPath('documents'),
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || !result.filePaths?.[0]) return { canceled: true };
  const folder = path.join(result.filePaths[0], `operator-wintweak-bundle-${Date.now()}`);
  await fs.mkdir(folder, { recursive: true });
  await fs.writeFile(path.join(folder, 'APPLY-operator-wintweak.ps1'), bundle?.apply || '', 'utf8');
  await fs.writeFile(path.join(folder, 'UNDO-operator-wintweak.ps1'), bundle?.undo || '', 'utf8');
  await fs.writeFile(path.join(folder, 'AUDIT-operator-report.ps1'), bundle?.audit || '', 'utf8');
  await fs.writeFile(path.join(folder, 'README.txt'), bundle?.readme || '', 'utf8');
  return { canceled: false, folder };
});

ipcMain.handle('folder:open', async (_event, folder) => {
  if (folder) await shell.openPath(folder);
});

ipcMain.handle('github:new', async () => {
  await shell.openExternal('https://github.com/new');
});

ipcMain.handle('powershell:version', () => new Promise((resolve) => {
  execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', '$PSVersionTable.PSVersion.ToString()'], { timeout: 7000 }, (err, stdout, stderr) => {
    resolve({ ok: !err, stdout: String(stdout || '').trim(), stderr: String(stderr || err?.message || '').trim() });
  });
}));
