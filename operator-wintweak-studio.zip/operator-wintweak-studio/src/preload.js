const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('operatorAPI', {
  minimize: () => ipcRenderer.invoke('window:minimize'),
  maximize: () => ipcRenderer.invoke('window:maximize'),
  close: () => ipcRenderer.invoke('window:close'),
  systemInfo: () => ipcRenderer.invoke('system:info'),
  powershellVersion: () => ipcRenderer.invoke('powershell:version'),
  saveScript: (payload) => ipcRenderer.invoke('script:save', payload),
  saveBundle: (bundle) => ipcRenderer.invoke('script:save-bundle', bundle),
  openFolder: (folder) => ipcRenderer.invoke('folder:open', folder),
  openGithubNew: () => ipcRenderer.invoke('github:new')
});
