const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

let currentView = 'dashboard';
let selectedIds = new Set();
let activeCategory = 'All';
let searchTerm = '';
let showUndo = false;
let toastTimer = null;
let sysInfo = null;
let psInfo = null;

const views = {
  dashboard: $('#dashboardView'),
  profiles: $('#profilesView'),
  tweaks: $('#tweaksView'),
  audit: $('#auditView'),
  scripts: $('#scriptsView'),
  docs: $('#docsView')
};

const profiles = [
  {
    id: 'baseline', icon: '🛡', title: 'Baseline Safe', risk: 'low',
    desc: 'Restore point, registry backup, Explorer sanity, firewall/Defender verification, safe privacy defaults.',
    ids: ['restore-point', 'registry-backup', 'show-extensions', 'firewall-on', 'defender-on', 'smartscreen-on', 'autorun-off', 'ad-id-off', 'activity-history-off', 'startup-audit']
  },
  {
    id: 'hardening', icon: '🔐', title: 'Defensive Hardening', risk: 'medium',
    desc: 'Security-focused workstation hardening without disabling security tooling or updates.',
    ids: ['restore-point', 'registry-backup', 'firewall-on', 'defender-on', 'pua-on', 'smartscreen-on', 'uac-on', 'autorun-off', 'smb1-off', 'llmnr-off', 'wpad-off', 'rdp-nla', 'startup-audit', 'listening-ports-audit']
  },
  {
    id: 'privacy', icon: '🕶', title: 'Privacy Respect', risk: 'low',
    desc: 'Turns off ad IDs, tailored experiences, activity history, app launch tracking, and noisy suggestions.',
    ids: ['restore-point', 'registry-backup', 'ad-id-off', 'tailored-off', 'activity-history-off', 'launch-tracking-off', 'feedback-off', 'suggestions-off', 'start-web-off']
  },
  {
    id: 'performance', icon: '⚡', title: 'Performance / Low-End', risk: 'medium',
    desc: 'Cleans temp files, trims visual effects, reduces animations, runs component cleanup, and offers power-plan tuning.',
    ids: ['restore-point', 'temp-clean', 'dns-flush', 'component-cleanup', 'visualfx-performance', 'animations-off', 'transparency-off', 'game-mode-on', 'game-dvr-off', 'power-high']
  },
  {
    id: 'gaming', icon: '🎮', title: 'Gaming Rig', risk: 'medium',
    desc: 'Game Mode, DVR capture reduction, temp cleanup, DNS flush, optional high-performance power mode.',
    ids: ['restore-point', 'game-mode-on', 'game-dvr-off', 'temp-clean', 'dns-flush', 'power-high', 'hags-on']
  },
  {
    id: 'developer', icon: '💻', title: 'Developer Mode', risk: 'medium',
    desc: 'File extensions, hidden files, full paths, long paths, startup audit, and diagnostic exports.',
    ids: ['restore-point', 'show-extensions', 'show-hidden', 'full-path-title', 'long-paths-on', 'startup-audit', 'installed-apps-audit']
  },
  {
    id: 'audit', icon: '📡', title: 'Recon / Audit Only', risk: 'low',
    desc: 'Read-only defensive inventory: services, startups, firewall, Defender, ports, users, updates, apps.',
    ids: ['startup-audit', 'listening-ports-audit', 'defender-audit', 'firewall-audit', 'services-audit', 'users-audit', 'updates-audit', 'installed-apps-audit', 'network-audit']
  }
];

const tweakCatalog = [
  {
    id: 'restore-point', category: 'Safety', risk: 'low', admin: true, reboot: false, recommended: true,
    title: 'Create system restore point',
    desc: 'Creates a restore point before applying settings. Requires System Protection enabled.',
    apply: ['Checkpoint-Computer -Description "Operator WinTweak Studio" -RestorePointType "MODIFY_SETTINGS"'],
    undo: ['Write-Host "Restore points are reverted from Windows System Restore." -ForegroundColor Yellow']
  },
  {
    id: 'registry-backup', category: 'Safety', risk: 'low', admin: false, reboot: false, recommended: true,
    title: 'Export registry safety snapshots',
    desc: 'Exports common tweak registry areas to your Desktop before changes.',
    apply: [
      '$BackupRoot = "$env:USERPROFILE\\Desktop\\OperatorWinTweak-RegistryBackup"',
      'New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null',
      'reg export "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" "$BackupRoot\\HKCU-Explorer-Advanced.reg" /y',
      'reg export "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" "$BackupRoot\\HKCU-Personalize.reg" /y',
      'reg export "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" "$BackupRoot\\HKCU-AdvertisingInfo.reg" /y',
      'Write-Host "Registry snapshots exported to $BackupRoot" -ForegroundColor Cyan'
    ],
    undo: ['Write-Host "Import the .reg files from the Desktop backup folder to restore snapshots." -ForegroundColor Yellow']
  },
  {
    id: 'show-extensions', category: 'Explorer', risk: 'low', admin: false, reboot: false, recommended: true,
    title: 'Show file extensions',
    desc: 'Makes .exe, .ps1, .zip, and other extensions visible.',
    apply: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name HideFileExt -Type DWord -Value 0', 'Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name HideFileExt -Type DWord -Value 1', 'Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue']
  },
  {
    id: 'show-hidden', category: 'Explorer', risk: 'medium', admin: false, reboot: false, recommended: false,
    title: 'Show hidden files',
    desc: 'Power-user setting. Shows hidden folders/files in Explorer.',
    apply: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name Hidden -Type DWord -Value 1', 'Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name Hidden -Type DWord -Value 2', 'Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue']
  },
  {
    id: 'full-path-title', category: 'Explorer', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Show full path in Explorer title bar',
    desc: 'Makes Explorer windows show the full folder path.',
    apply: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\CabinetState" -Name FullPath -Type DWord -Value 1'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\CabinetState" -Name FullPath -Type DWord -Value 0']
  },
  {
    id: 'firewall-on', category: 'Hardening', risk: 'low', admin: true, reboot: false, recommended: true,
    title: 'Ensure Windows Firewall is enabled',
    desc: 'Turns firewall on for Domain, Private, and Public profiles.',
    apply: ['Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True'],
    undo: ['Write-Warning "Firewall disable undo is intentionally not generated. Turn it off manually only if you know why."']
  },
  {
    id: 'defender-on', category: 'Hardening', risk: 'low', admin: true, reboot: false, recommended: true,
    title: 'Ensure Microsoft Defender protections are enabled',
    desc: 'Defensive setting: real-time monitoring, behavior monitoring, IOAV, script scanning, and cloud protection on.',
    apply: [
      'Set-MpPreference -DisableRealtimeMonitoring $false',
      'Set-MpPreference -DisableBehaviorMonitoring $false',
      'Set-MpPreference -DisableIOAVProtection $false',
      'Set-MpPreference -DisableScriptScanning $false',
      'Set-MpPreference -MAPSReporting Advanced',
      'Set-MpPreference -SubmitSamplesConsent SendSafeSamples'
    ],
    undo: ['Write-Warning "Defender disable undo is intentionally not generated. This studio does not weaken endpoint security."']
  },
  {
    id: 'pua-on', category: 'Hardening', risk: 'low', admin: true, reboot: false, recommended: false,
    title: 'Enable Potentially Unwanted App protection',
    desc: 'Blocks or warns on bundled/adware-like unwanted apps.',
    apply: ['Set-MpPreference -PUAProtection Enabled'],
    undo: ['Set-MpPreference -PUAProtection Disabled']
  },
  {
    id: 'smartscreen-on', category: 'Hardening', risk: 'low', admin: true, reboot: false, recommended: true,
    title: 'Enable SmartScreen / reputation checks',
    desc: 'Keeps SmartScreen-style file/app reputation protection enabled.',
    apply: [
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer" -Name SmartScreenEnabled -Type String -Value "RequireAdmin"',
      'New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\AppHost" -Force | Out-Null',
      'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\AppHost" -Name EnableWebContentEvaluation -Type DWord -Value 1'
    ],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\AppHost" -Name EnableWebContentEvaluation -Type DWord -Value 0']
  },
  {
    id: 'uac-on', category: 'Hardening', risk: 'medium', admin: true, reboot: true, recommended: false,
    title: 'Ensure UAC is enabled',
    desc: 'Enables UAC. Reboot required if it was disabled.',
    apply: ['Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" -Name EnableLUA -Type DWord -Value 1'],
    undo: ['Write-Warning "UAC disable undo is intentionally not generated."']
  },
  {
    id: 'autorun-off', category: 'Hardening', risk: 'low', admin: true, reboot: false, recommended: true,
    title: 'Disable AutoRun / AutoPlay execution',
    desc: 'Reduces removable-media auto-execution risk.',
    apply: [
      'New-Item -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" -Force | Out-Null',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" -Name NoDriveTypeAutoRun -Type DWord -Value 255',
      'New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoplayHandlers" -Force | Out-Null',
      'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoplayHandlers" -Name DisableAutoplay -Type DWord -Value 1'
    ],
    undo: [
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" -Name NoDriveTypeAutoRun -Type DWord -Value 145',
      'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoplayHandlers" -Name DisableAutoplay -Type DWord -Value 0'
    ]
  },
  {
    id: 'smb1-off', category: 'Hardening', risk: 'medium', admin: true, reboot: true, recommended: false,
    title: 'Disable SMBv1 protocol',
    desc: 'Disables legacy SMBv1. Avoid if you rely on very old NAS/printers.',
    apply: ['Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart'],
    undo: ['Enable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart']
  },
  {
    id: 'llmnr-off', category: 'Hardening', risk: 'medium', admin: true, reboot: false, recommended: false,
    title: 'Disable LLMNR name resolution',
    desc: 'Reduces local-network spoofing exposure on managed/advanced systems.',
    apply: ['New-Item -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\DNSClient" -Force | Out-Null', 'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\DNSClient" -Name EnableMulticast -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\DNSClient" -Name EnableMulticast -Type DWord -Value 1']
  },
  {
    id: 'wpad-off', category: 'Hardening', risk: 'medium', admin: true, reboot: false, recommended: false,
    title: 'Reduce WPAD auto-proxy exposure',
    desc: 'Disables WinHTTP auto-proxy service startup. Avoid in enterprise proxy environments.',
    apply: ['Set-Service -Name WinHttpAutoProxySvc -StartupType Disabled -ErrorAction SilentlyContinue'],
    undo: ['Set-Service -Name WinHttpAutoProxySvc -StartupType Manual -ErrorAction SilentlyContinue']
  },
  {
    id: 'rdp-nla', category: 'Hardening', risk: 'medium', admin: true, reboot: false, recommended: false,
    title: 'Require Network Level Authentication for RDP',
    desc: 'If RDP is enabled, requires NLA. Safer than weakening remote desktop.',
    apply: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp" -Name UserAuthentication -Type DWord -Value 1'],
    undo: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp" -Name UserAuthentication -Type DWord -Value 0']
  },
  {
    id: 'rdp-off', category: 'Hardening', risk: 'high', admin: true, reboot: false, recommended: false,
    title: 'Disable inbound Remote Desktop',
    desc: 'Security hardening for PCs that do not need RDP. Do not use on remote servers you depend on.',
    apply: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server" -Name fDenyTSConnections -Type DWord -Value 1', 'Disable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue'],
    undo: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server" -Name fDenyTSConnections -Type DWord -Value 0', 'Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue']
  },
  {
    id: 'ad-id-off', category: 'Privacy', risk: 'low', admin: false, reboot: false, recommended: true,
    title: 'Disable advertising ID',
    desc: 'Turns off per-user advertising ID.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" -Name Enabled -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" -Name Enabled -Type DWord -Value 1']
  },
  {
    id: 'tailored-off', category: 'Privacy', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Disable tailored experiences',
    desc: 'Reduces personalization based on diagnostic data.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy" -Name TailoredExperiencesWithDiagnosticDataEnabled -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy" -Name TailoredExperiencesWithDiagnosticDataEnabled -Type DWord -Value 1']
  },
  {
    id: 'activity-history-off', category: 'Privacy', risk: 'low', admin: false, reboot: false, recommended: true,
    title: 'Disable activity history publishing/upload',
    desc: 'Stops activity publishing and upload values for current user policies.',
    apply: ['New-Item -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" -Force | Out-Null', 'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" -Name PublishUserActivities -Type DWord -Value 0', 'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" -Name UploadUserActivities -Type DWord -Value 0'],
    undo: ['Remove-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" -Name PublishUserActivities -ErrorAction SilentlyContinue', 'Remove-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" -Name UploadUserActivities -ErrorAction SilentlyContinue']
  },
  {
    id: 'launch-tracking-off', category: 'Privacy', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Disable app launch tracking',
    desc: 'Stops Windows from tracking app launches to personalize Start/search results.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name Start_TrackProgs -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name Start_TrackProgs -Type DWord -Value 1']
  },
  {
    id: 'feedback-off', category: 'Privacy', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Reduce feedback prompts',
    desc: 'Reduces feedback notification prompts for the current user.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Siuf\\Rules" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Siuf\\Rules" -Name NumberOfSIUFInPeriod -Type DWord -Value 0', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Siuf\\Rules" -Name PeriodInNanoSeconds -Type QWord -Value 0'],
    undo: ['Remove-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Siuf\\Rules" -Name NumberOfSIUFInPeriod -ErrorAction SilentlyContinue', 'Remove-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Siuf\\Rules" -Name PeriodInNanoSeconds -ErrorAction SilentlyContinue']
  },
  {
    id: 'suggestions-off', category: 'Privacy', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Reduce Windows suggestions/tips',
    desc: 'Turns off several current-user content delivery suggestion toggles.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name SubscribedContent-338389Enabled -Type DWord -Value 0', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name SoftLandingEnabled -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name SubscribedContent-338389Enabled -Type DWord -Value 1', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name SoftLandingEnabled -Type DWord -Value 1']
  },
  {
    id: 'start-web-off', category: 'Privacy', risk: 'medium', admin: false, reboot: false, recommended: false,
    title: 'Disable web suggestions in Windows Search',
    desc: 'Reduces web search/suggestion behavior in Start/Search for the current user.',
    apply: ['New-Item -Path "HKCU:\\Software\\Policies\\Microsoft\\Windows\\Explorer" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Policies\\Microsoft\\Windows\\Explorer" -Name DisableSearchBoxSuggestions -Type DWord -Value 1'],
    undo: ['Remove-ItemProperty -Path "HKCU:\\Software\\Policies\\Microsoft\\Windows\\Explorer" -Name DisableSearchBoxSuggestions -ErrorAction SilentlyContinue']
  },
  {
    id: 'temp-clean', category: 'Performance', risk: 'low', admin: false, reboot: false, recommended: true,
    title: 'Clean user temp files',
    desc: 'Deletes files from your user TEMP folder. In-use files are skipped.',
    apply: ['Remove-Item -Path "$env:TEMP\\*" -Recurse -Force -ErrorAction SilentlyContinue'],
    undo: ['Write-Host "Temp cleanup cannot be automatically undone." -ForegroundColor Yellow']
  },
  {
    id: 'dns-flush', category: 'Network', risk: 'low', admin: false, reboot: false, recommended: true,
    title: 'Flush DNS cache',
    desc: 'Safe network troubleshooting action.',
    apply: ['Clear-DnsClientCache'],
    undo: ['Write-Host "DNS cache flush has no undo." -ForegroundColor Yellow']
  },
  {
    id: 'component-cleanup', category: 'Performance', risk: 'medium', admin: true, reboot: false, recommended: false,
    title: 'DISM component cleanup',
    desc: 'Runs Windows component cleanup. Safe, but can take time.',
    apply: ['DISM.exe /Online /Cleanup-Image /StartComponentCleanup'],
    undo: ['Write-Host "Component cleanup cannot be automatically undone." -ForegroundColor Yellow']
  },
  {
    id: 'sfc-scan', category: 'Performance', risk: 'medium', admin: true, reboot: false, recommended: false,
    title: 'System file integrity scan',
    desc: 'Runs SFC /scannow to verify and repair Windows system files.',
    apply: ['sfc /scannow'],
    undo: ['Write-Host "SFC repairs cannot be automatically undone." -ForegroundColor Yellow']
  },
  {
    id: 'power-high', category: 'Performance', risk: 'medium', admin: false, reboot: false, recommended: false,
    title: 'Use High Performance power plan',
    desc: 'Good for desktops. Not ideal for laptop battery life.',
    apply: ['powercfg /setactive SCHEME_MIN'],
    undo: ['powercfg /setactive SCHEME_BALANCED']
  },
  {
    id: 'visualfx-performance', category: 'Performance', risk: 'medium', admin: false, reboot: false, recommended: false,
    title: 'Visual effects: performance mode',
    desc: 'Reduces visual effects for older or slower PCs.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" -Name VisualFXSetting -Type DWord -Value 2'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" -Name VisualFXSetting -Type DWord -Value 0']
  },
  {
    id: 'animations-off', category: 'Performance', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Reduce Windows animations',
    desc: 'Turns off window/taskbar animations for snappier UI.',
    apply: ['Set-ItemProperty -Path "HKCU:\\Control Panel\\Desktop\\WindowMetrics" -Name MinAnimate -Type String -Value "0"'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Control Panel\\Desktop\\WindowMetrics" -Name MinAnimate -Type String -Value "1"']
  },
  {
    id: 'transparency-off', category: 'Performance', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Disable transparency effects',
    desc: 'Reduces compositor visual overhead and gives a cleaner UI.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" -Name EnableTransparency -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" -Name EnableTransparency -Type DWord -Value 1']
  },
  {
    id: 'game-mode-on', category: 'Gaming', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Enable Game Mode',
    desc: 'Enables Windows Game Mode and auto game mode.',
    apply: ['New-Item -Path "HKCU:\\Software\\Microsoft\\GameBar" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\GameBar" -Name AllowAutoGameMode -Type DWord -Value 1', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\GameBar" -Name AutoGameModeEnabled -Type DWord -Value 1'],
    undo: ['Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\GameBar" -Name AllowAutoGameMode -Type DWord -Value 0', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\GameBar" -Name AutoGameModeEnabled -Type DWord -Value 0']
  },
  {
    id: 'game-dvr-off', category: 'Gaming', risk: 'low', admin: false, reboot: false, recommended: false,
    title: 'Disable Game DVR background capture',
    desc: 'Reduces background recording overhead. You can undo if you use Xbox capture.',
    apply: ['New-Item -Path "HKCU:\\System\\GameConfigStore" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\System\\GameConfigStore" -Name GameDVR_Enabled -Type DWord -Value 0', 'New-Item -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR" -Force | Out-Null', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR" -Name AppCaptureEnabled -Type DWord -Value 0'],
    undo: ['Set-ItemProperty -Path "HKCU:\\System\\GameConfigStore" -Name GameDVR_Enabled -Type DWord -Value 1', 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR" -Name AppCaptureEnabled -Type DWord -Value 1']
  },
  {
    id: 'hags-on', category: 'Gaming', risk: 'medium', admin: true, reboot: true, recommended: false,
    title: 'Enable Hardware Accelerated GPU Scheduling',
    desc: 'May help or hurt depending on GPU/driver. Requires reboot.',
    apply: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name HwSchMode -Type DWord -Value 2'],
    undo: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name HwSchMode -Type DWord -Value 1']
  },
  {
    id: 'long-paths-on', category: 'Developer', risk: 'medium', admin: true, reboot: false, recommended: false,
    title: 'Enable Win32 long paths',
    desc: 'Allows long file paths for supported apps.',
    apply: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\FileSystem" -Name LongPathsEnabled -Type DWord -Value 1'],
    undo: ['Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\FileSystem" -Name LongPathsEnabled -Type DWord -Value 0']
  },
  {
    id: 'startup-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: true, auditOnly: true,
    title: 'Export startup app audit',
    desc: 'Read-only export of startup commands to Desktop.',
    apply: ['Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, Location, User | Sort-Object Name | Format-Table -AutoSize | Out-String | Set-Content "$ReportRoot\\startup-commands.txt"'],
    undo: ['Remove-Item "$ReportRoot\\startup-commands.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'listening-ports-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export listening network ports',
    desc: 'Read-only local listening TCP port inventory.',
    apply: ['Get-NetTCPConnection -State Listen | Sort-Object LocalPort | Select-Object LocalAddress,LocalPort,OwningProcess | Format-Table -AutoSize | Out-String | Set-Content "$ReportRoot\\listening-tcp-ports.txt"'],
    undo: ['Remove-Item "$ReportRoot\\listening-tcp-ports.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'defender-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export Defender status',
    desc: 'Read-only Defender health and configuration snapshot.',
    apply: ['Get-MpComputerStatus | Format-List * | Out-String | Set-Content "$ReportRoot\\defender-status.txt"', 'Get-MpPreference | Format-List * | Out-String | Set-Content "$ReportRoot\\defender-preferences.txt"'],
    undo: ['Remove-Item "$ReportRoot\\defender-status.txt","$ReportRoot\\defender-preferences.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'firewall-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export firewall profile status',
    desc: 'Read-only firewall profile and enabled rule summary.',
    apply: ['Get-NetFirewallProfile | Format-List * | Out-String | Set-Content "$ReportRoot\\firewall-profiles.txt"', 'Get-NetFirewallRule -Enabled True | Select-Object DisplayName,Direction,Action,Profile | Sort-Object DisplayName | Out-String | Set-Content "$ReportRoot\\firewall-enabled-rules.txt"'],
    undo: ['Remove-Item "$ReportRoot\\firewall-profiles.txt","$ReportRoot\\firewall-enabled-rules.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'services-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export auto-start services',
    desc: 'Read-only inventory of automatic services.',
    apply: ['Get-CimInstance Win32_Service | Where-Object {$_.StartMode -eq "Auto"} | Select-Object Name,DisplayName,State,StartName,PathName | Sort-Object Name | Out-String | Set-Content "$ReportRoot\\auto-services.txt"'],
    undo: ['Remove-Item "$ReportRoot\\auto-services.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'users-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export local users and admins',
    desc: 'Read-only local user and Administrators group inventory.',
    apply: ['Get-LocalUser | Select-Object Name,Enabled,LastLogon,PasswordRequired | Format-Table -AutoSize | Out-String | Set-Content "$ReportRoot\\local-users.txt"', 'Get-LocalGroupMember Administrators | Format-Table -AutoSize | Out-String | Set-Content "$ReportRoot\\local-admins.txt"'],
    undo: ['Remove-Item "$ReportRoot\\local-users.txt","$ReportRoot\\local-admins.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'updates-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export installed updates',
    desc: 'Read-only hotfix/update inventory.',
    apply: ['Get-HotFix | Sort-Object InstalledOn -Descending | Format-Table -AutoSize | Out-String | Set-Content "$ReportRoot\\installed-updates.txt"'],
    undo: ['Remove-Item "$ReportRoot\\installed-updates.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'installed-apps-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export installed apps inventory',
    desc: 'Read-only installed software inventory from uninstall registry keys.',
    apply: ['Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* -ErrorAction SilentlyContinue | Where-Object DisplayName | Select-Object DisplayName,DisplayVersion,Publisher,InstallDate | Sort-Object DisplayName | Format-Table -AutoSize | Out-String -Width 4096 | Set-Content "$ReportRoot\\installed-apps.txt"'],
    undo: ['Remove-Item "$ReportRoot\\installed-apps.txt" -ErrorAction SilentlyContinue']
  },
  {
    id: 'network-audit', category: 'Audit', risk: 'low', admin: false, reboot: false, recommended: false, auditOnly: true,
    title: 'Export network configuration',
    desc: 'Read-only network adapter/IP/DNS route inventory.',
    apply: ['Get-NetIPConfiguration | Format-List * | Out-String | Set-Content "$ReportRoot\\network-ip-configuration.txt"', 'Get-DnsClientServerAddress | Format-Table -AutoSize | Out-String | Set-Content "$ReportRoot\\dns-servers.txt"', 'Get-NetRoute | Sort-Object RouteMetric | Select-Object DestinationPrefix,NextHop,RouteMetric,InterfaceAlias | Out-String | Set-Content "$ReportRoot\\routes.txt"'],
    undo: ['Remove-Item "$ReportRoot\\network-ip-configuration.txt","$ReportRoot\\dns-servers.txt","$ReportRoot\\routes.txt" -ErrorAction SilentlyContinue']
  }
];

function toast(message, ms = 2800) {
  if (toastTimer) clearTimeout(toastTimer);
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), ms);
}

function setView(name) {
  currentView = name;
  $$('.nav').forEach((btn) => btn.classList.toggle('active', btn.dataset.view === name));
  Object.values(views).forEach((view) => view.classList.remove('active'));
  views[name].classList.add('active');
  render();
}

async function init() {
  selectedIds = new Set(tweakCatalog.filter((t) => t.recommended).map((t) => t.id));
  sysInfo = await window.operatorAPI.systemInfo().catch(() => null);
  psInfo = await window.operatorAPI.powershellVersion().catch(() => null);
  render();
}

function render() {
  if (currentView === 'dashboard') renderDashboard();
  if (currentView === 'profiles') renderProfiles();
  if (currentView === 'tweaks') renderTweaks();
  if (currentView === 'audit') renderAudit();
  if (currentView === 'scripts') renderScripts();
  if (currentView === 'docs') renderDocs();
}

function score() {
  const defensive = ['restore-point', 'registry-backup', 'firewall-on', 'defender-on', 'smartscreen-on', 'autorun-off', 'show-extensions'];
  const selected = defensive.filter((id) => selectedIds.has(id)).length;
  const highRisk = selectedTweaks().filter((t) => t.risk === 'high').length;
  return Math.max(25, Math.min(100, 48 + selected * 7 - highRisk * 10));
}

function renderDashboard() {
  const selected = selectedTweaks();
  const adminCount = selected.filter((t) => t.admin).length;
  const rebootCount = selected.filter((t) => t.reboot).length;
  views.dashboard.innerHTML = `
    <div class="hero">
      <h1>Operator-grade, defensive only.</h1>
      <p>Build transparent Windows hardening, privacy, performance, and audit scripts. This is the legit version of “elite”: readable PowerShell, restore-first workflow, undo generation, and no shady security bypasses.</p>
      <div class="badges">
        <span class="badge green">No Defender disable</span>
        <span class="badge green">No malware persistence</span>
        <span class="badge green">No exploit chains</span>
        <span class="badge">PowerShell script generator</span>
        <span class="badge">GitHub-ready</span>
      </div>
      <div class="actionRow">
        <button class="primary" data-go="profiles">Choose Profile</button>
        <button class="secondary" data-go="tweaks">Open Tweak Matrix</button>
        <button class="secondary" data-go="scripts">Generate Scripts</button>
      </div>
    </div>
    <div class="grid">
      <div class="card metric"><span>Readiness Score</span><b>${score()}/100</b></div>
      <div class="card metric"><span>Selected Tweaks</span><b>${selected.length}</b></div>
      <div class="card metric"><span>Admin Required</span><b>${adminCount}</b></div>
      <div class="card metric"><span>May Need Reboot</span><b>${rebootCount}</b></div>
      <div class="card metric"><span>PowerShell</span><b>${psInfo?.ok ? escapeHTML(psInfo.stdout) : 'Unknown'}</b></div>
      <div class="card metric"><span>Host</span><b>${escapeHTML(sysInfo?.hostname || 'Unknown')}</b></div>
    </div>
    <div class="grid">
      ${sysInfo ? Object.entries(sysInfo).slice(0, 8).map(([k,v]) => `<div class="card"><span class="badge">${escapeHTML(k)}</span><p><b>${escapeHTML(v)}</b></p></div>`).join('') : ''}
    </div>`;
  views.dashboard.querySelectorAll('[data-go]').forEach((btn) => btn.addEventListener('click', () => setView(btn.dataset.go)));
}

function renderProfiles() {
  views.profiles.innerHTML = `
    <div class="hero" style="margin-bottom:18px">
      <h1>Profiles</h1>
      <p>Pick a preset. You can still edit every individual tweak after selecting one.</p>
      <div class="actionRow"><button class="secondary" id="clearAll">Clear All</button><button class="secondary" id="recommended">Recommended Baseline</button></div>
    </div>
    <div class="profileGrid">
      ${profiles.map((p) => `<div class="profile"><div class="profileIcon">${p.icon}</div><h3>${escapeHTML(p.title)}</h3><p>${escapeHTML(p.desc)}</p><div class="badges"><span class="badge ${p.risk === 'low' ? 'green' : 'yellow'}">${p.risk} risk</span><span class="badge">${p.ids.length} items</span></div><div class="actionRow"><button class="primary" data-profile="${p.id}">Load Profile</button><button class="secondary" data-add="${p.id}">Add To Current</button></div></div>`).join('')}
    </div>`;
  $('#clearAll').onclick = () => { selectedIds.clear(); toast('Selection cleared'); renderProfiles(); };
  $('#recommended').onclick = () => { selectedIds = new Set(tweakCatalog.filter((t) => t.recommended).map((t) => t.id)); toast('Recommended baseline selected'); renderProfiles(); };
  views.profiles.querySelectorAll('[data-profile]').forEach((btn) => btn.onclick = () => {
    const p = profiles.find((x) => x.id === btn.dataset.profile);
    selectedIds = new Set(p.ids);
    toast(`${p.title} loaded`);
    setView('tweaks');
  });
  views.profiles.querySelectorAll('[data-add]').forEach((btn) => btn.onclick = () => {
    const p = profiles.find((x) => x.id === btn.dataset.add);
    p.ids.forEach((id) => selectedIds.add(id));
    toast(`${p.title} added to current selection`);
    renderProfiles();
  });
}

function categories() {
  return ['All', ...Array.from(new Set(tweakCatalog.map((t) => t.category))).sort()];
}

function filteredTweaks() {
  return tweakCatalog.filter((t) => {
    const categoryOk = activeCategory === 'All' || t.category === activeCategory;
    const haystack = `${t.title} ${t.desc} ${t.category} ${t.risk}`.toLowerCase();
    const searchOk = !searchTerm || haystack.includes(searchTerm.toLowerCase());
    return categoryOk && searchOk;
  });
}

function renderTweaks() {
  const filtered = filteredTweaks();
  views.tweaks.innerHTML = `
    <div class="tweakLayout">
      <div class="panel filterBox">
        <h2>Tweak Matrix</h2>
        <input class="search" id="search" placeholder="Search tweaks..." value="${escapeAttr(searchTerm)}">
        <select class="select" id="category">${categories().map((c) => `<option ${c === activeCategory ? 'selected' : ''}>${escapeHTML(c)}</option>`).join('')}</select>
        <div class="actionRow">
          <button class="secondary" id="selectVisible">Select Visible</button>
          <button class="secondary" id="clearVisible">Clear Visible</button>
          <button class="secondary" id="selectRecommended">Recommended</button>
        </div>
        <p>${selectedIds.size} selected. Low risk = reversible/simple. Medium/high = read carefully.</p>
      </div>
      <div class="panel">
        ${filtered.map((t) => `<label class="tweakItem"><input type="checkbox" data-id="${t.id}" ${selectedIds.has(t.id) ? 'checked' : ''}><span><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(t.desc)}</small><div class="badges"><span class="badge">${escapeHTML(t.category)}</span>${t.admin ? '<span class="badge yellow">admin</span>' : ''}${t.reboot ? '<span class="badge yellow">reboot</span>' : ''}${t.auditOnly ? '<span class="badge green">audit only</span>' : ''}</div></span><span class="risk ${t.risk}">${t.risk}</span></label>`).join('')}
      </div>
    </div>`;
  $('#search').oninput = (e) => { searchTerm = e.target.value; renderTweaks(); };
  $('#category').onchange = (e) => { activeCategory = e.target.value; renderTweaks(); };
  views.tweaks.querySelectorAll('[data-id]').forEach((box) => box.onchange = () => {
    if (box.checked) selectedIds.add(box.dataset.id);
    else selectedIds.delete(box.dataset.id);
  });
  $('#selectVisible').onclick = () => { filtered.forEach((t) => selectedIds.add(t.id)); renderTweaks(); };
  $('#clearVisible').onclick = () => { filtered.forEach((t) => selectedIds.delete(t.id)); renderTweaks(); };
  $('#selectRecommended').onclick = () => { selectedIds = new Set(tweakCatalog.filter((t) => t.recommended).map((t) => t.id)); renderTweaks(); };
}

function renderAudit() {
  const auditTweaks = tweakCatalog.filter((t) => t.category === 'Audit');
  views.audit.innerHTML = `
    <div class="hero" style="margin-bottom:18px"><h1>Audit Builder</h1><p>Read-only reconnaissance for your own PC: inventory services, users, firewall, Defender, ports, apps, updates, and networking. Great for GitHub issue reports and before/after tuning snapshots.</p></div>
    <div class="twoCol">
      <div class="panel"><h2>Audit modules</h2><div class="auditList">${auditTweaks.map((t) => `<label><input type="checkbox" data-audit="${t.id}" ${selectedIds.has(t.id) ? 'checked' : ''}> <b>${escapeHTML(t.title)}</b><br><small>${escapeHTML(t.desc)}</small></label>`).join('')}</div><div class="actionRow"><button class="primary" id="selectAuditAll">Select All Audit</button><button class="secondary" id="clearAudit">Clear Audit</button></div></div>
      <div class="panel"><h2>Audit script preview</h2><textarea class="script audit" readonly>${escapeHTML(generateAuditScript())}</textarea></div>
    </div>`;
  views.audit.querySelectorAll('[data-audit]').forEach((box) => box.onchange = () => { if (box.checked) selectedIds.add(box.dataset.audit); else selectedIds.delete(box.dataset.audit); renderAudit(); });
  $('#selectAuditAll').onclick = () => { auditTweaks.forEach((t) => selectedIds.add(t.id)); renderAudit(); };
  $('#clearAudit').onclick = () => { auditTweaks.forEach((t) => selectedIds.delete(t.id)); renderAudit(); };
}

function renderScripts() {
  const apply = generateApplyScript();
  const undo = generateUndoScript();
  const audit = generateAuditScript();
  views.scripts.innerHTML = `
    <div class="hero" style="margin-bottom:18px"><h1>Script Output</h1><p>Save an APPLY script, UNDO script, and AUDIT script. The app does not silently execute tweaks — you read and run them yourself.</p><div class="actionRow"><button class="primary" id="saveBundle">Save Full Bundle</button><button class="secondary" id="copyCurrent">Copy Current Tab</button><button class="secondary" id="toggleUndo">${showUndo ? 'Show Apply Script' : 'Show Undo Script'}</button></div></div>
    <div class="twoCol">
      <div class="panel"><h2>${showUndo ? 'UNDO PowerShell' : 'APPLY PowerShell'}</h2><textarea class="script" id="mainScript" spellcheck="false">${escapeHTML(showUndo ? undo : apply)}</textarea><div class="actionRow"><button class="primary" id="saveMain">Save This Script</button><button class="secondary" id="copyMain">Copy</button></div></div>
      <div class="panel"><h2>AUDIT PowerShell</h2><textarea class="script audit" id="auditScript" spellcheck="false">${escapeHTML(audit)}</textarea><div class="actionRow"><button class="primary" id="saveAudit">Save Audit</button><button class="secondary" id="copyAudit">Copy Audit</button></div></div>
    </div>`;
  $('#toggleUndo').onclick = () => { showUndo = !showUndo; renderScripts(); };
  $('#copyMain').onclick = async () => { await navigator.clipboard.writeText($('#mainScript').value); toast('Script copied'); };
  $('#copyCurrent').onclick = async () => { await navigator.clipboard.writeText($('#mainScript').value); toast('Current script copied'); };
  $('#copyAudit').onclick = async () => { await navigator.clipboard.writeText($('#auditScript').value); toast('Audit script copied'); };
  $('#saveMain').onclick = async () => { const res = await window.operatorAPI.saveScript({ title: 'Save script', defaultName: showUndo ? 'UNDO-operator-wintweak.ps1' : 'APPLY-operator-wintweak.ps1', text: $('#mainScript').value }); if (!res.canceled) toast(`Saved ${res.filePath}`); };
  $('#saveAudit').onclick = async () => { const res = await window.operatorAPI.saveScript({ title: 'Save audit script', defaultName: 'AUDIT-operator-report.ps1', text: $('#auditScript').value }); if (!res.canceled) toast(`Saved ${res.filePath}`); };
  $('#saveBundle').onclick = async () => {
    const readme = bundleReadme();
    const res = await window.operatorAPI.saveBundle({ apply, undo, audit, readme });
    if (!res.canceled) { toast(`Bundle saved ${res.folder}`); await window.operatorAPI.openFolder(res.folder); }
  };
}

function renderDocs() {
  views.docs.innerHTML = `
    <div class="hero" style="margin-bottom:18px"><h1>GitHub / Safety</h1><p>Post it as a defensive Windows tuning and audit tool. Keep the rules clear: no malware behavior, no security bypasses, no exploit automation.</p><div class="actionRow"><button class="primary" id="openGithub">Open GitHub New Repo</button><button class="secondary" id="copyGit">Copy Git Commands</button></div></div>
    <div class="grid">
      <div class="card"><h3>Positioning</h3><p>“Operator-grade defensive hardening, privacy, performance, and audit script generator for Windows.”</p></div>
      <div class="card"><h3>Safe Policy</h3><p>No Defender disable. No Windows Update disable. No stealth. No persistence. No credential access. No exploit chains.</p></div>
      <div class="card"><h3>Build EXE</h3><div class="code">npm install<br>npm run make:win</div></div>
      <div class="card"><h3>Run Scripts</h3><p>Right-click PowerShell → Run as Administrator → read the script → run intentionally.</p></div>
    </div>
    <div class="panel" style="margin-top:18px"><h2>Git commands</h2><div class="code">git init<br>git add .<br>git commit -m "Initial release"<br>git branch -M main<br>git remote add origin https://github.com/YOURNAME/operator-wintweak-studio.git<br>git push -u origin main</div></div>`;
  $('#openGithub').onclick = () => window.operatorAPI.openGithubNew();
  $('#copyGit').onclick = async () => { await navigator.clipboard.writeText('git init\ngit add .\ngit commit -m "Initial release"\ngit branch -M main\ngit remote add origin https://github.com/YOURNAME/operator-wintweak-studio.git\ngit push -u origin main'); toast('Git commands copied'); };
}

function selectedTweaks() {
  return tweakCatalog.filter((t) => selectedIds.has(t.id));
}

function scriptHeader(title) {
  const date = new Date().toISOString();
  return [
    '# Operator WinTweak Studio',
    `# ${title}`,
    `# Generated: ${date}`,
    '# Defensive/transparent Windows script. Read before running.',
    '# This script intentionally does NOT disable Defender, Firewall, Windows Update, SmartScreen, UAC, or install persistence.',
    '$ErrorActionPreference = "Continue"',
    '$IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)',
    'if (-not $IsAdmin) { Write-Warning "Some selected actions require Administrator PowerShell." }',
    '$ReportRoot = "$env:USERPROFILE\\Desktop\\OperatorWinTweak-Report"',
    'New-Item -ItemType Directory -Path $ReportRoot -Force | Out-Null',
    'Start-Transcript -Path "$ReportRoot\\operator-wintweak-transcript.txt" -Append',
    '$confirm = Read-Host "Type APPLY to continue, anything else to cancel"',
    'if ($confirm -ne "APPLY") { Write-Host "Canceled." -ForegroundColor Yellow; Stop-Transcript; exit }',
    ''
  ].join('\n');
}

function scriptFooter() {
  return [
    '',
    'Write-Host "Complete. Review $ReportRoot and restart Windows if needed." -ForegroundColor Green',
    'Stop-Transcript'
  ].join('\n');
}

function generateApplyScript() {
  const lines = [scriptHeader('APPLY script')];
  for (const tweak of selectedTweaks()) {
    lines.push(`# --- ${tweak.title} ---`);
    lines.push(`Write-Host "Applying: ${psEscape(tweak.title)}" -ForegroundColor Cyan`);
    for (const cmd of tweak.apply) lines.push(cmd);
    lines.push('');
  }
  lines.push(scriptFooter());
  return lines.join('\n');
}

function generateUndoScript() {
  const lines = [scriptHeader('UNDO script')];
  for (const tweak of selectedTweaks().slice().reverse()) {
    lines.push(`# --- UNDO: ${tweak.title} ---`);
    lines.push(`Write-Host "Undo: ${psEscape(tweak.title)}" -ForegroundColor Yellow`);
    for (const cmd of tweak.undo) lines.push(cmd);
    lines.push('');
  }
  lines.push(scriptFooter());
  return lines.join('\n');
}

function generateAuditScript() {
  const auditTweaks = selectedTweaks().filter((t) => t.category === 'Audit');
  const use = auditTweaks.length ? auditTweaks : tweakCatalog.filter((t) => t.category === 'Audit' && t.recommended);
  const lines = [
    '# Operator WinTweak Studio',
    '# AUDIT script - read-only defensive inventory',
    '$ErrorActionPreference = "Continue"',
    '$ReportRoot = "$env:USERPROFILE\\Desktop\\OperatorWinTweak-Audit"',
    'New-Item -ItemType Directory -Path $ReportRoot -Force | Out-Null',
    'Start-Transcript -Path "$ReportRoot\\audit-transcript.txt" -Append',
    'Get-ComputerInfo | Out-String | Set-Content "$ReportRoot\\computer-info.txt"',
    'Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime | Format-List | Out-String | Set-Content "$ReportRoot\\os-summary.txt"',
    ''
  ];
  for (const tweak of use) {
    lines.push(`# --- ${tweak.title} ---`);
    for (const cmd of tweak.apply) lines.push(cmd);
    lines.push('');
  }
  lines.push('Stop-Transcript');
  lines.push('Write-Host "Audit complete: $ReportRoot" -ForegroundColor Green');
  return lines.join('\n');
}

function bundleReadme() {
  return `Operator WinTweak Studio Bundle\n\nFiles:\n- APPLY-operator-wintweak.ps1: applies selected tweaks\n- UNDO-operator-wintweak.ps1: attempts to revert selected tweaks where possible\n- AUDIT-operator-report.ps1: read-only defensive inventory\n\nRecommended run order:\n1. Read every script.\n2. Run AUDIT first.\n3. Run APPLY from Administrator PowerShell if you accept the changes.\n4. Restart Windows if needed.\n5. Keep the UNDO script and registry backups.\n\nSafety policy:\nNo Defender bypass, no exploit chains, no persistence, no credential access, no stealth behavior.\n`;
}

function psEscape(value) {
  return String(value).replace(/"/g, '`"');
}

function escapeHTML(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

function escapeAttr(value) {
  return escapeHTML(value).replace(/`/g, '&#96;');
}

$('#minBtn').onclick = () => window.operatorAPI.minimize();
$('#maxBtn').onclick = () => window.operatorAPI.maximize();
$('#closeBtn').onclick = () => window.operatorAPI.close();
$$('.nav').forEach((btn) => btn.addEventListener('click', () => setView(btn.dataset.view)));

init();
