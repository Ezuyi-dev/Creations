# Safe Tweak Policy

This project is allowed to generate scripts that improve security posture, privacy, usability, or performance.

It must not generate scripts that:

- Disable Microsoft Defender
- Disable Windows Firewall
- Disable Windows Update
- Disable SmartScreen
- Disable UAC
- Add persistence
- Hide processes/files/users
- Dump credentials
- Bypass endpoint security
- Download and execute remote payloads
- Obfuscate commands

The goal is transparent defensive administration, not offensive operations.
